/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  Image,
  Dimensions,
  TouchableOpacity,
  View
} from 'react-native';
//merchant.com.wildnet.react
const {width , height} = Dimensions.get('window');
//global.PaymentRequest = require('react-native-payments').PaymentRequest;

import Tts from 'react-native-tts';


import CustomNav from '../../component/customNav/customNav'
export default class SpeechRecognition extends Component {
    constructor(props){
        super(props);
        this.speak = this.speak.bind(this);
        this.state = {dummyText:'This is the dummy text to check text to speech functionality.This demo is in React Native.'}
        
    }

componentDidMount(){
  Tts.addEventListener('tts-start', (event) => console.log("start", event));
Tts.addEventListener('tts-finish', (event) => console.log("finish", event));
Tts.addEventListener('tts-cancel', (event) => console.log("cancel", event));

Tts.setDefaultLanguage('en-US');

Tts.setDefaultPitch(1.0);

}

speak(){
  Tts.speak(this.state.dummyText);
}
    
  render() {
    return (
      <View style={styles.container}>
        <CustomNav  openDrawer = {()=>this.props.openDrawer}/>
        <View style={styles.TextContainer}>
         <Text style = {{fontSize: 20,textAlign:'center' }} multiline = {true} >{this.state.dummyText}</Text>
        </View>

        <TouchableOpacity style = {styles.btnContainer} onPress = {()=> this.speak()}>
         <Text style={[styles.hintText, {color:'gray' ,fontWeight:'bold', marginTop:0}]}>Speak</Text>
         </TouchableOpacity>
       
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor:'white'
  },
  TextContainer:{
    width: width * 0.80 , 
    left: width*0.10,
    height : 100,
    borderWidth:2.0,
    borderRadius :4 ,
    top : 40,
    borderColor: 'gray',
    justifyContent: 'center' ,
    alignItems: 'center'
  },hintText : {
    width : null,
    fontSize: width*0.06,
    textAlign: 'center',
    marginTop: 20,
    backgroundColor: "transparent",
    color: 'white',
  },
  btnContainer : {
      marginTop : 100 ,
      width : width*0.60,
      left : width*0.20,
      height:50,
      justifyContent: 'center',
      alignItems:'center' ,
      borderRadius: 25,
      backgroundColor:'black',
  }
});

