import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Easing,
  Animated,
  Platform,
  Image,
  TouchableOpacity,
  TouchableHighlight,
  ScrollView
} from 'react-native';


export default class Spin extends Component {

  constructor () {
  super()
  this.spinValue = new Animated.Value(0)
}

componentDidMount () {
this.spin()
}

renderBackBtn(){
  if (Platform.OS == 'ios'){
    return(
      <TouchableOpacity style = {styles.backBtn} onPress ={()=> this.props.navigation.goBack()}>
      <Text>BACK</Text></TouchableOpacity>
    )
  }else{
    return(
      <View />
    )
  }
}


spin () {
this.spinValue.setValue(0)
Animated.timing(
this.spinValue,
{
  toValue: 1,
  duration: 4000,
  easing: Easing.linear
}
).start(() => this.spin())
}

render () {
const spin = this.spinValue.interpolate({
  inputRange: [0, 1],
  outputRange: ['0deg', '360deg']
})
return (
  <View style={styles.container}>
  {this.renderBackBtn()}
  <View style={styles.midContainer}>
    <Animated.Image
      style={{
        width: 227,
        height: 200,
        transform: [{rotate: spin}] }}
        source={{uri: 'https://s3.amazonaws.com/media-p.slid.es/uploads/alexanderfarennikov/images/1198519/reactjs.png'}}
    />
    </View>
  </View>
);
}
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
  }, midContainer:{
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  backBtn:{
    marginLeft: 20,
    marginTop: 20 ,
    width : 80 ,
    height : 40
  }
})
