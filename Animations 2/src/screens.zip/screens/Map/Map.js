/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  Image,
  Dimensions,
  TouchableOpacity,
  View
} from 'react-native';

var {
    MapManager
} = require('NativeModules');

const SPACE = 0.01;

import MapView from 'react-native-maps';
//merchant.com.wildnet.react
const {width , height} = Dimensions.get('window');
//global.PaymentRequest = require('react-native-payments').PaymentRequest;
import CustomNav from '../../component/customNav/customNav'
export default class MapScreen extends Component {
    constructor(props){
        super(props);
        this.showMap = this.showMap.bind(this);
        this.state = {region:null};
        
    }

    showMap(){
        //MapManager.intializeMap();
        alert('hi');
       // MapManager.setPositionWith(position.coords.latitude,position.coords.longitude);
    }

    componentDidMount(){
    // MapManager.intializeMap()

        this.watchID = navigator.geolocation.watchPosition((position) => {
      // Create the object to update this.state.mapRegion through the onRegionChange function
      let region = {
        latitude:       position.coords.latitude,
        longitude:      position.coords.longitude,
        latitudeDelta:  0.00922*1.5,
        longitudeDelta: 0.00421*1.5
      }
      this.setState({region:region});

      console.log(" "+position.coords.latitude+"long"+position.coords.longitude)
      //this.onRegionChange(region, region.latitude, region.longitude);
     // MapManager.setPositionWith(position.coords.latitude,position.coords.longitude);
    });
    }

    renderMap() {
      if (this.state.region === null) {
        return (<View />)
      }else{
       let lattitude = this.state.region.latitude ;
       let longitude = this.state.region.longitude ;
        return ( <MapView
         style= 
         {{flex: 1}}
    initialRegion={this.state.region}
  >

    <MapView.Marker
      coordinate={{
              latitude: lattitude ,
              longitude:  longitude,
            }}
      title={'I am here'}
      description={'My Location'}
    />

</MapView>



  )
       
      }
    }

    
  render() {
    return (
      <View style={styles.container}>
        <CustomNav  openDrawer = {()=>this.props.openDrawer}/>
        {this.renderMap() } 
        
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor:'white'
  },
  busImgContainer:{
    width : width , 
    height : 180 , 
    top : height*0.15,
    alignItems:'center'
  },
  ticketImgContainer:{
    width : width , 
    height : 240 , 
    top : 60,
    alignItems:'center'
  },
  bgView :{
    position : 'absolute',
    width : width ,
    height : height ,
    backgroundColor : 'rgba(1,1,1,0.4)'
  },
  backgroundImg :{
      position : 'absolute',
      width : width ,
      height : height
  },welcomeText : {
    fontSize: 20,
    textAlign: 'center',
    backgroundColor: "transparent",
    color: 'gray',
    fontWeight: 'bold',
    marginTop: 20
  },
  profileContainer:{
    width : width*0.40 ,
    height :width*0.40 ,
    marginTop : 20
  },hintText : {
    width : null,
    fontSize: width*0.06,
    textAlign: 'center',
    marginTop: 20,
    backgroundColor: "transparent",
    color: 'white',
  },
  btnContainer : {
      marginTop : 40 ,
      width : width*0.60,
      left  :width*0.20,
      height:50,
      justifyContent: 'center',
      alignItems:'center' ,
      borderRadius: 25,
      backgroundColor:'black',
  }
});
